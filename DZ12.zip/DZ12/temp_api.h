#ifndef TEMP_API_H
#define TEMP_API_H

/* --------------------------------------------------------------
   Структура записи о температуре:
   yyyy mm dd hh tt temperature
   -------------------------------------------------------------- */
typedef struct {
    int year;        /* 4‑digit year               */
    int month;       /* 1 … 12                    */
    int day;         /* 1 … 31                    */
    int hour;        /* 0 … 23                    */
    int minute;      /* 0 … 59                    */
    int temperature;/* -99 … +99                 */
} TempRecord;

/* ----- прототипы функций статистики --------------------------- */
void print_month_average(int month, const TempRecord *rec, int n);
void print_month_min    (int month, const TempRecord *rec, int n);
void print_month_max    (int month, const TempRecord *rec, int n);

void print_year_average(const TempRecord *rec, int n);
void print_year_min    (const TempRecord *rec, int n);
void print_year_max    (const TempRecord *rec, int n);

/* ----- прототипы вспомогательных функций -------------------- */
int  add_record   (TempRecord **arr, int *size, const TempRecord *new_rec);
int  del_record   (TempRecord * arr, int *size, int index); /* returns 0/1 */
int  cmp_records  (const void *a, const void *b);          /* qsort */
void sort_records (TempRecord *arr, int n);
void print_all    (const TempRecord *arr, int n);

#endif /* TEMP_API_H */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "temp_api.h"

#define HELP_TEXT \
"Usage: tempapp [options]\n"\
"\nOptions:\n"\
"  -h               show this help message\n"\
"  -f <file.csv>    input CSV file (required)\n"\
"  -m <month>       show statistics only for the given month (1‑12)\n"

static int read_csv(const char *fname, TempRecord **out_arr, int *out_cnt)
{
    FILE *f = fopen(fname, "r");
    if (!f) return 0;

    TempRecord *arr = NULL;
    int cnt = 0;
    while (1) {
        TempRecord r;
        /* читаем до запятой/конца строки, игнорируем пробелы */
        int rc = fscanf(f,
            " %d , %d , %d , %d , %d , %d ",
            &r.year, &r.month, &r.day,
            &r.hour, &r.minute, &r.temperature);
        if (rc != 6) break;               /* EOF или плохая строка */

        if (!add_record(&arr, &cnt, &r)) { fclose(f); return 0; }
    }
    fclose(f);
    *out_arr = arr;
    *out_cnt = cnt;
    return 1;
}

int main(int argc, char **argv)
{
    const char *filename = NULL;
    int month_filter = 0;

    /* ---- разбор аргументов ------------------------------------ */
    for (int i = 1; i < argc; ++i) {
        if (!strcmp(argv[i], "-h")) {
            puts(HELP_TEXT);
            return 0;
        } else if (!strcmp(argv[i], "-f") && i + 1 < argc) {
            filename = argv[++i];
        } else if (!strcmp(argv[i], "-m") && i + 1 < argc) {
            month_filter = atoi(argv[++i]);
            if (month_filter < 1 || month_filter > 12) {
                fprintf(stderr, "Invalid month number.\n");
                return 1;
            }
        } else {
            fprintf(stderr, "Unknown option: %s\n", argv[i]);
            puts(HELP_TEXT);
            return 1;
        }
    }

    if (!filename) {               /* обязательный параметр */
        fprintf(stderr, "Error: input file required (-f <file.csv>)\n");
        puts(HELP_TEXT);
        return 1;
    }

    /* ---- чтение CSV ------------------------------------------- */
    TempRecord *records = NULL;
    int rec_cnt = 0;
    if (!read_csv(filename, &records, &rec_cnt)) {
        fprintf(stderr, "Failed to read \"%s\"\n", filename);
        return 1;
    }
    if (rec_cnt == 0) {
        puts("No records found.");
        free(records);
        return 0;
    }

    /* сортируем для удобного вывода */
    sort_records(records, rec_cnt);

    /* ---- вывод ----------------------------------------------- */
    if (month_filter) {
        print_month_average(month_filter, records, rec_cnt);
        print_month_min    (month_filter, records, rec_cnt);
        print_month_max    (month_filter, records, rec_cnt);
    } else {
        print_year_average(records, rec_cnt);
        print_year_min    (records, rec_cnt);
        print_year_max    (records, rec_cnt);
    }

    /* необязательно: печать всех записей */
    puts("\nAll records:");
    print_all(records, rec_cnt);

    free(records);
    return 0;
}
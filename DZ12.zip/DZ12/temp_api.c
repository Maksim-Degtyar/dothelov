#include <stdio.h>
#include <stdlib.h>
#include "temp_api.h"

/* ---------- вспомогательная функция: среднее ----------------- */
static double avg_temp(const TempRecord *rec, int cnt)
{
    if (cnt == 0) return 0.0;
    long sum = 0;
    for (int i = 0; i < cnt; ++i) sum += rec[i].temperature;
    return (double)sum / cnt;
}

/* ---------- статистика по отдельному месяцу ------------------- */
void print_month_average(int month, const TempRecord *rec, int n)
{
    long sum = 0;
    int  cnt = 0;
    for (int i = 0; i < n; ++i)
        if (rec[i].month == month) { sum += rec[i].temperature; ++cnt; }

    printf("Month %02d average: %.2f\n", month,
           cnt ? (double)sum / cnt : 0.0);
}

void print_month_min(int month, const TempRecord *rec, int n)
{
    int min = 100;                     /* > maximal possible */
    for (int i = 0; i < n; ++i)
        if (rec[i].month == month && rec[i].temperature < min)
            min = rec[i].temperature;

    if (min == 100) printf("Month %02d – no data.\n", month);
    else            printf("Month %02d min: %d\n", month, min);
}

void print_month_max(int month, const TempRecord *rec, int n)
{
    int max = -100;                    /* < minimal possible */
    for (int i = 0; i < n; ++i)
        if (rec[i].month == month && rec[i].temperature > max)
            max = rec[i].temperature;

    if (max == -100) printf("Month %02d – no data.\n", month);
    else            printf("Month %02d max: %d\n", month, max);
}

/* ---------- статистика за весь год --------------------------- */
void print_year_average(const TempRecord *rec, int n)
{
    double avg = avg_temp(rec, n);
    printf("Year average temperature: %.2f\n", avg);
}

void print_year_min(const TempRecord *rec, int n)
{
    int min = 100;
    for (int i = 0; i < n; ++i)
        if (rec[i].temperature < min) min = rec[i].temperature;

    if (min == 100) printf("Year – no data.\n");
    else            printf("Year minimal temperature: %d\n", min);
}

void print_year_max(const TempRecord *rec, int n)
{
    int max = -100;
    for (int i = 0; i < n; ++i)
        if (rec[i].temperature > max) max = rec[i].temperature;

    if (max == -100) printf("Year – no data.\n");
    else            printf("Year maximal temperature: %d\n", max);
}

/* ---------- функции управления массивом ---------------------- */
int add_record(TempRecord **arr, int *size, const TempRecord *new_rec)
{
    TempRecord *tmp = realloc(*arr, (*size + 1) * sizeof(TempRecord));
    if (!tmp) return 0;                     /* allocation failure */

    tmp[*size] = *new_rec;
    ++*size;
    *arr = tmp;
    return 1;
}

/* удалить запись по индексу (0‑based). Возврат 1 – удалено, 0 – неверный индекс */
int del_record(TempRecord *arr, int *size, int index)
{
    if (index < 0 || index >= *size) return 0;

    for (int i = index; i + 1 < *size; ++i)
        arr[i] = arr[i + 1];
    --*size;
    return 1;
}

/* сравнение для qsort: сначала по году, потом месяц, день, время */
int cmp_records(const void *a, const void *b)
{
    const TempRecord *ra = a;
    const TempRecord *rb = b;

    if (ra->year   != rb->year)   return ra->year   - rb->year;
    if (ra->month  != rb->month)  return ra->month  - rb->month;
    if (ra->day    != rb->day)    return ra->day    - rb->day;
    if (ra->hour   != rb->hour)   return ra->hour   - rb->hour;
    if (ra->minute != rb->minute) return ra->minute - rb->minute;
    return 0;
}

void sort_records(TempRecord *arr, int n)
{
    qsort(arr, n, sizeof(TempRecord), cmp_records);
}

/* печать всего массива */
void print_all(const TempRecord *arr, int n)
{
    for (int i = 0; i < n; ++i) {
        printf("%04d-%02d-%02d %02d:%02d  %3d\n",
               arr[i].year, arr[i].month, arr[i].day,
               arr[i].hour, arr[i].minute,
               arr[i].temperature);
    }
}

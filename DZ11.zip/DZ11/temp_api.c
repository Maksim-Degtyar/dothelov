#include <stdio.h>
#include "temp_api.h"

/* вспомогательная функция – среднее значение */
static double avg_temp(const TempRecord *rec, int cnt)
{
    if (cnt == 0) return 0.0;
    long sum = 0;
    for (int i = 0; i < cnt; ++i) sum += rec[i].temperature;
    return (double)sum / cnt;
}

/* ---------- месяц ---------- */
void print_month_average(int month, const TempRecord *rec, int n)
{
    long sum = 0;
    int  cnt = 0;
    for (int i = 0; i < n; ++i)
        if (rec[i].month == month) { sum += rec[i].temperature; ++cnt; }

    printf("Month %02d average: %.2f\n", month,
           cnt ? (double)sum / cnt : 0.0);
}

void print_month_min(int month, const TempRecord *rec, int n)
{
    int min = 100;                     /* больше максимально возможного */
    for (int i = 0; i < n; ++i)
        if (rec[i].month == month && rec[i].temperature < min)
            min = rec[i].temperature;

    if (min == 100) printf("Month %02d has no data.\n", month);
    else            printf("Month %02d min: %d\n", month, min);
}

void print_month_max(int month, const TempRecord *rec, int n)
{
    int max = -100;                    /* меньше минимального */
    for (int i = 0; i < n; ++i)
        if (rec[i].month == month && rec[i].temperature > max)
            max = rec[i].temperature;

    if (max == -100) printf("Month %02d has no data.\n", month);
    else             printf("Month %02d max: %d\n", month, max);
}

/* ---------- год ---------- */
void print_year_average(const TempRecord *rec, int n)
{
    double avg = avg_temp(rec, n);
    printf("Year average temperature: %.2f\n", avg);
}

void print_year_min(const TempRecord *rec, int n)
{
    int min = 100;
    for (int i = 0; i < n; ++i)
        if (rec[i].temperature < min) min = rec[i].temperature;

    if (min == 100) printf("No data for the year.\n");
    else            printf("Year minimal temperature: %d\n", min);
}

void print_year_max(const TempRecord *rec, int n)
{
    int max = -100;
    for (int i = 0; i < n; ++i)
        if (rec[i].temperature > max) max = rec[i].temperature;

    if (max == -100) printf("No data for the year.\n");
    else             printf("Year maximal temperature: %d\n", max);
}
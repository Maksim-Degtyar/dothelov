
#ifndef TEMP_API_H
#define TEMP_API_H

/* Структура записи о температуре */
typedef struct {
    int year;        /* yyyy – 4 цифры */
    int month;       /* mm   – 1..12 */
    int day;         /* dd   – 1..31 */
    int hour;        /* hh   – 0..23 */
    int minute;      /* tt   – 0..59 */
    int temperature;/* -99 .. +99 */
} TempRecord;

/* Прототипы функций‑заглушек */

/* статистика за указанный месяц */
void print_month_average(int month, const TempRecord *records, int count);
void print_month_min    (int month, const TempRecord *records, int count);
void print_month_max    (int month, const TempRecord *records, int count);

/* статистика за весь год */
void print_year_average(const TempRecord *records, int count);
void print_year_min    (const TempRecord *records, int count);
void print_year_max    (const TempRecord *records, int count);

#endif /* TEMP_API_H */
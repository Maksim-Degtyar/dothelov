#include <stdio.h>
#include "temp_api.h"

int main(void)
{
    /* пример массива записей о температуре */
    TempRecord data[] = {
        {2023, 1, 12, 14, 30, 15},
        {2023, 1, 13, 10, 45,-5},
        {2023, 2, 05, 9 , 15, 20},
        {2023, 2, 06,22 , 0 ,-12},
        {2023, 3, 01,8 ,10, 5}
    };
    const int n = sizeof(data) / sizeof(data[0]);

    /* статистика по каждому из первых трёх месяцев */
    for (int m = 1; m <= 3; ++m) {
        print_month_average(m, data, n);
        print_month_min    (m, data, n);
        print_month_max    (m, data, n);
        putchar('\n');
    }

    /* статистика за год */
    print_year_average(data, n);
    print_year_min    (data, n);
    print_year_max    (data, n);

    return 0;
}